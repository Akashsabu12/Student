// File: src/main/java/com/yourcompany/studentapp/service/StudentService.java

package com.yourcompany.studentapp.service;

import java.util.List;
import com.yourcompany.studentapp.model.Student;

public interface StudentService {
    List<Student> getAllStudents();
}

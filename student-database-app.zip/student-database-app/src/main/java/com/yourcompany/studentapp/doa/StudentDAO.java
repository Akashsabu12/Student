// File: src/main/java/com/yourcompany/studentapp/dao/StudentDAO.java

package com.yourcompany.studentapp.dao;

import com.yourcompany.studentapp.model.Student;

import java.util.List;

public interface StudentDAO {
    List<Student> getAllStudents();
}

// File: src/main/java/com/yourcompany/studentapp/controller/StudentController.java

package com.yourcompany.studentapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StudentController {

    @GetMapping("/students")
    public String getAllStudents(Model model) {
        // Add logic to fetch students from the database and pass them to the view
        return "students";
    }
}
